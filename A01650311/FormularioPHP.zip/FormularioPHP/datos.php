<html>
    <body>
        <h1>Datos </h1>
        Nombre: <?php echo $_POST["name"]; ?><br>
        Telefono: <?php echo $_POST["tel"]; ?><br>
        Correo: <?php echo $_POST["email"]; ?><br>
        Mensaje: <?php echo $_POST["msg"]; ?><br>
    </body>
</html>